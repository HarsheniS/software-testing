from django.contrib import admin
from .models import SupermarketModel,Items,CustomerBill

admin.site.register(SupermarketModel)
admin.site.register(Items)
admin.site.register(CustomerBill)

# Register your models here.

# Register your models here.
